 <!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="home.css">
  </head>

    <!-- navbar -->
<?php
include 'navbar.php'
?>

<!-- div after nav -->
<div class="background-home">
  <img class="logo-on-home" src="logo_new.png" alt="">
</div>
</html>
