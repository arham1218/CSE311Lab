<?php
$otp ="";
$name;
$email;
$username;
$password ;
?>
 